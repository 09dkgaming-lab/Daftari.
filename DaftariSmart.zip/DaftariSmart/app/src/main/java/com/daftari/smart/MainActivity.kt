package com.daftari.smart

import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Customer(val id: Long, val name: String, val phone: String, val balance: Long)

class StoreDb(ctx: android.content.Context) : SQLiteOpenHelper(ctx, "daftari.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT DEFAULT '', created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_id INTEGER NOT NULL, amount INTEGER NOT NULL, description TEXT, kind TEXT NOT NULL, method TEXT DEFAULT '', created_at INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    fun addCustomer(name: String, phone: String) {
        writableDatabase.insert("customers", null, ContentValues().apply {
            put("name", name.trim()); put("phone", phone.trim()); put("created_at", System.currentTimeMillis())
        })
    }
    fun customers(): List<Customer> {
        val out = mutableListOf<Customer>()
        readableDatabase.rawQuery("SELECT c.id,c.name,c.phone,COALESCE(SUM(CASE WHEN t.kind='دين' THEN t.amount WHEN t.kind='تسديد' THEN -t.amount ELSE 0 END),0) balance FROM customers c LEFT JOIN transactions t ON c.id=t.customer_id GROUP BY c.id ORDER BY c.name", null).use {
            while (it.moveToNext()) out.add(Customer(it.getLong(0), it.getString(1), it.getString(2), it.getLong(3)))
        }
        return out
    }
    fun addTransaction(id: Long, amount: Long, desc: String, kind: String, method: String) {
        writableDatabase.insert("transactions", null, ContentValues().apply {
            put("customer_id", id); put("amount", amount); put("description", desc); put("kind", kind); put("method", method); put("created_at", System.currentTimeMillis())
        })
    }
    fun statement(id: Long): String {
        var debt = 0L; var paid = 0L
        val lines = mutableListOf<String>()
        readableDatabase.rawQuery("SELECT amount,description,kind,method,created_at FROM transactions WHERE customer_id=? ORDER BY created_at DESC", arrayOf(id.toString())).use { c ->
            while (c.moveToNext()) {
                val amount=c.getLong(0); val desc=c.getString(1) ?: ""; val kind=c.getString(2); val method=c.getString(3) ?: ""
                if (kind=="دين") debt += amount else paid += amount
                val date=SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(c.getLong(4)))
                lines.add("$date | $kind | $amount ريال | $desc | $method")
            }
        }
        return "إجمالي الدين: $debt ريال\nإجمالي المسدد: $paid ريال\nالباقي: ${debt-paid} ريال\n\n${lines.joinToString("\n")}"
    }
}

class MainActivity : AppCompatActivity() {
    private lateinit var db: StoreDb
    private lateinit var root: LinearLayout
    private val green=Color.rgb(23,107,69); private val red=Color.rgb(183,45,45)
    private val methods=listOf("نقد - مناولة يد","جيب","ون كاش","فلوسك","جوالي","كريمي جوي / جوال","حوالة الكريمي","حوالة نجم","حوالة حزمي","حوالة الامتياز","حوالة الهتار","حوالة العامري","حوالة العيدروس","حوالة دادية","حوالة المميز","حوالة اليمنية","حوالة الأكوع","حوالة البرق","حوالة مال","حوالة Hb","حوالة المحيط","حوالة الناصر")
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db=StoreDb(this); showHome() }
    private fun setup(title:String) {
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(18,16,18,20); setBackgroundColor(Color.rgb(248,249,246)) }
        val scroll=ScrollView(this); scroll.addView(root); setContentView(scroll)
        root.addView(TextView(this).apply { text=title; textSize=26f; gravity=Gravity.CENTER; setTextColor(green); setPadding(0,8,0,16) })
    }
    private fun button(text:String,color:Int=green,action:()->Unit) {
        root.addView(Button(this).apply { this.text=text; textSize=18f; setTextColor(Color.WHITE); backgroundTintList=android.content.res.ColorStateList.valueOf(color); setOnClickListener { action() } }, LinearLayout.LayoutParams(-1,58).apply { bottomMargin=7 })
    }
    private fun label(text:String) { root.addView(TextView(this).apply { this.text=text; textSize=17f; setTextColor(Color.DKGRAY); setPadding(0,8,0,4) }) }
    private fun field(hint:String,numeric:Boolean=false):EditText {
        val e=EditText(this).apply { this.hint=hint; textSize=19f; setPadding(12,6,12,6) }
        if(numeric) e.inputType=InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        root.addView(e,LinearLayout.LayoutParams(-1,58).apply { bottomMargin=7 }); return e
    }
    private fun showHome() {
        setup("📒 دفتري\nدفترك وحاسبتك في جيبك")
        button("＋ إضافة زبون") { addCustomer() }
        button("🧮 حاسبة عامة",Color.rgb(50,90,150)) { calculator {} }
        button("📊 التقارير") { reports() }
        button("💾 مشاركة نسخة احتياطية") { backup() }
        label("الزبائن")
        val customers=db.customers()
        if(customers.isEmpty()) label("لا يوجد زبائن بعد. أضف أول زبون.")
        customers.forEach { c ->
            root.addView(Button(this).apply {
                text="${c.name}\n${c.phone}\nالباقي عليه: ${c.balance} ريال"; textSize=17f; setTextColor(Color.WHITE)
                backgroundTintList=android.content.res.ColorStateList.valueOf(if(c.balance>0) red else green)
                setOnClickListener { customerPage(c) }
            },LinearLayout.LayoutParams(-1,82).apply { bottomMargin=7 })
        }
    }
    private fun addCustomer() {
        setup("إضافة زبون"); val name=field("اسم الحساب: أحمد علي"); val phone=field("رقم الواتساب")
        button("حفظ الزبون") { if(name.text.isBlank()) name.error="اكتب اسم الزبون" else { db.addCustomer(name.text.toString(),phone.text.toString()); showHome() } }
        button("رجوع") { showHome() }
    }
    private fun customerPage(c:Customer) {
        setup("حساب: ${c.name}"); label("واتساب: ${c.phone}"); label("الباقي عليه: ${c.balance} ريال")
        button("＋ إضافة حركة / دين",red) { transaction(c,"دين") }
        button("✓ تسديد",green) { transaction(c,"تسديد") }
        button("📒 كشف حساب") { AlertDialog.Builder(this).setTitle("كشف حساب ${c.name}").setMessage(db.statement(c.id)).setPositiveButton("واتساب") { _,_-> whatsapp(c,db.statement(c.id)) }.setNeutralButton("مشاركة") { _,_-> share(db.statement(c.id)) }.setNegativeButton("إغلاق",null).show() }
        button("تذكير واتساب") { whatsapp(c,"مرحباً ${c.name}، نذكّرك بمراجعة حساب البقالة. الرصيد الحالي: ${c.balance} ريال.") }
        button("رجوع") { showHome() }
    }
    private fun transaction(c:Customer,kind:String) {
        setup(if(kind=="دين") "تسجيل دين جديد" else "تسجيل تسديد")
        label("الزبون: ${c.name} — الرصيد الحالي ${c.balance} ريال")
        val amount=field(if(kind=="دين") "المبلغ" else "المبلغ المسدد",true)
        button("🧮 الحاسبة الذكية",Color.rgb(50,90,150)) { calculator { amount.setText(it) } }
        val desc=field("البيان / المناولة")
        val quick=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        listOf("رز","سكر","زيت","دقيق","بيض","مناولة","سداد مناولة").forEach { item ->
            quick.addView(Button(this).apply { text=item; textSize=11f; setOnClickListener { desc.append(if(desc.text.isNotEmpty()) " + $item" else item) } },LinearLayout.LayoutParams(0,48,1f))
        }; root.addView(quick)
        var method=""
        if(kind=="تسديد") {
            label("طريقة القبض"); val spinner=Spinner(this)
            spinner.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,methods); root.addView(spinner)
            spinner.onItemSelectedListener=object:AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent:android.widget.AdapterView<*>?) {}
                override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long) { method=methods[position] }
            }
        }
        button(if(kind=="دين") "حفظ كـ دين" else "تأكيد السداد",if(kind=="دين") red else green) {
            val n=amount.text.toString().toDoubleOrNull()
            if(n==null || n<=0) { amount.error="أدخل مبلغاً صحيحاً"; return@button }
            db.addTransaction(c.id,n.toLong(),desc.text.toString(),kind,method)
            val msg=if(kind=="دين") "تم تسجيل دين جديد بمبلغ ${n.toLong()} ريال في حساب ${c.name}. البيان: ${desc.text}" else "تم تسجيل سداد ${n.toLong()} ريال في حساب ${c.name}."
            AlertDialog.Builder(this).setTitle("تم الحفظ").setMessage("هل تريد إرسال إشعار واتساب؟").setPositiveButton("إرسال") { _,_-> whatsapp(c,msg); customerPage(c) }.setNegativeButton("لاحقاً") { _,_-> customerPage(c) }.show()
        }
        button("إلغاء") { customerPage(c) }
    }
    private fun calculator(apply:(String)->Unit) {
        val box=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(8,6,8,6) }
        val expr=TextView(this).apply { textSize=19f; gravity=Gravity.END; setTextColor(Color.DKGRAY) }
        val result=TextView(this).apply { text="0"; textSize=28f; gravity=Gravity.END; setTextColor(green) }
        box.addView(expr); box.addView(result); var expression=""
        fun calc():Double? {
            return try {
                val s=expression.replace("×","*").replace("÷","/")
                val tokens=Regex("(?<=[+*/-])|(?=[+*/-])").split(s).filter{it.isNotBlank()}
                var total=tokens[0].toDouble(); var i=1
                while(i<tokens.size) { val op=tokens[i]; val v=tokens[i+1].toDouble(); total=when(op){"+"->total+v;"-"->total-v;"*"->total*v;"/"->if(v==0.0) return null else total/v;else->return null}; i+=2 }; total
            } catch(_:Exception) { null }
        }
        val grid=GridLayout(this).apply { columnCount=4 }
        listOf("7","8","9","÷","4","5","6","×","1","2","3","-","0",".","=","+").forEach { key ->
            grid.addView(Button(this).apply { text=key; textSize=19f; setOnClickListener {
                if(key=="=") result.text=calc()?.toString() ?: "خطأ" else { expression+=key; expr.text=expression; result.text=calc()?.toString() ?: "" }
            } },GridLayout.LayoutParams().apply { width=0; height=52; columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f); setMargins(2,2,2,2) })
        }; box.addView(grid)
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
        row.addView(Button(this).apply { text="مسح"; setOnClickListener { expression="";expr.text="";result.text="0" } },LinearLayout.LayoutParams(0,52,1f))
        lateinit var dialog:AlertDialog
        row.addView(Button(this).apply { text="تطبيق المبلغ"; setOnClickListener { val v=calc(); if(v!=null && v>=0) { apply(if(v%1.0==0.0) v.toLong().toString() else v.toString()); dialog.dismiss() } else Toast.makeText(this@MainActivity,"تحقق من العملية",Toast.LENGTH_SHORT).show() } },LinearLayout.LayoutParams(0,52,2f))
        box.addView(row); dialog=AlertDialog.Builder(this).setTitle("الحاسبة الذكية").setView(box).setNegativeButton("إغلاق",null).create(); dialog.show()
    }
    private fun whatsapp(c:Customer,message:String) {
        if(c.phone.isBlank()) { Toast.makeText(this,"أضف رقم واتساب أولاً",Toast.LENGTH_LONG).show(); return }
        val uri=Uri.parse("https://wa.me/${c.phone.replace("+","").replace(" ","")}?text=${Uri.encode(message)}")
        try { startActivity(Intent(Intent.ACTION_VIEW,uri)) } catch(_:Exception) { share(message) }
    }
    private fun share(message:String) { startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply { type="text/plain"; putExtra(Intent.EXTRA_TEXT,message) },"مشاركة")) }
    private fun reports() {
        setup("التقارير"); var debt=0L; var paid=0L
        db.readableDatabase.rawQuery("SELECT kind,COALESCE(SUM(amount),0) FROM transactions GROUP BY kind",null).use { c -> while(c.moveToNext()) if(c.getString(0)=="دين") debt=c.getLong(1) else paid=c.getLong(1) }
        label("إجمالي الديون: $debt ريال"); label("إجمالي التسديدات: $paid ريال"); label("صافي الرصيد: ${debt-paid} ريال")
        button("رجوع") { showHome() }
    }
    private fun backup() {
        val content=StringBuilder("DAFTARI BACKUP\n")
        db.readableDatabase.rawQuery("SELECT id,name,phone FROM customers ORDER BY id",null).use { c -> while(c.moveToNext()) content.append("CUSTOMER|${c.getLong(0)}|${c.getString(1)}|${c.getString(2)}\n") }
        db.readableDatabase.rawQuery("SELECT customer_id,amount,description,kind,method,created_at FROM transactions ORDER BY id",null).use { c -> while(c.moveToNext()) content.append("TX|${c.getLong(0)}|${c.getLong(1)}|${c.getString(2)}|${c.getString(3)}|${c.getString(4)}|${c.getLong(5)}\n") }
        share(content.toString())
    }
}
